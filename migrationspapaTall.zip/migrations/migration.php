
<?php

require_once __DIR__ . '/../vendor/autoload.php';

use PDO;

function prompt(string $message): string {
    echo $message;
    return trim(fgets(STDIN));
}

$driver = strtolower(prompt("Quel SGBD utiliser ? (mysql / pgsql) : "));
$host = prompt("Hôte (default: 127.0.0.1) : ") ?: "127.0.0.1";
$port = prompt("Port (default: 3306 ou 5432) : ") ?: ($driver === 'pgsql' ? "5432" : "3306");
$user = prompt("Utilisateur (default: root) : ") ?: "root";
$pass = prompt("Mot de passe : ");
$dbName = prompt("Nom de la base à créer : ");

try {

    $dsn = "$driver:host=$host;port=$port";
    $pdo = new PDO($dsn, $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        if ($driver === 'mysql') {
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            echo " Base `$dbName` créée avec succès.\n";
            $pdo->exec("USE `$dbName`");
        } elseif ($driver === 'pgsql') {
            $check = $pdo->query("SELECT 1 FROM pg_database WHERE datname = '$dbName'")->fetch();
            if (!$check) {
                $pdo->exec("CREATE DATABASE \"$dbName\"");
                echo "Base PostgreSQL `$dbName` créée.\n Relancez la migration pour créer les tables.\n";
                exit;
            } else {
                echo "ℹBase PostgreSQL `$dbName` déjà existante.\n";
            }
        }

    $dsn = "$driver:host=$host;port=$port;dbname=$dbName";
    $pdo = new PDO($dsn, $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $tables = [

        "CREATE TABLE IF NOT EXISTS client (
            id SERIAL PRIMARY KEY,
            nom VARCHAR(100) NOT NULL,
            prenom VARCHAR(100) NOT NULL,
            adresse VARCHAR(255),
            telephone VARCHAR(20)
        );",

        "CREATE TABLE IF NOT EXISTS compte (
            id SERIAL PRIMARY KEY,
            numerotelephone VARCHAR(20) UNIQUE NOT NULL,
            numerocni VARCHAR(20),
            photorecto VARCHAR(255),
            photoverso VARCHAR(255),
            solde DOUBLE PRECISION DEFAULT 0,
            estprincipale BOOLEAN DEFAULT false,
            id_client INTEGER NOT NULL,
            FOREIGN KEY (id_client) REFERENCES client(id) ON DELETE CASCADE
        );",

        "CREATE TABLE IF NOT EXISTS servicecommercial (
            id SERIAL PRIMARY KEY,
            login VARCHAR(100) UNIQUE NOT NULL,
            motdepasse VARCHAR(255) NOT NULL
        );",

        "CREATE TYPE IF NOT EXISTS transaction_type AS ENUM ('depot', 'retrait', 'transfert');",

        "CREATE TABLE IF NOT EXISTS transaction (
            id SERIAL PRIMARY KEY,
            date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            montant DOUBLE PRECISION NOT NULL,
            numcomptedepot INTEGER,
            numcomptedestinataire INTEGER,
            type transaction_type NOT NULL,
            id_compte INTEGER NOT NULL,
            FOREIGN KEY (id_compte) REFERENCES compte(id) ON DELETE CASCADE,
            FOREIGN KEY (numcomptedepot) REFERENCES compte(id),
            FOREIGN KEY (numcomptedestinataire) REFERENCES compte(id)
        );"
    ];

    foreach ($tables as $sql) {
        $pdo->exec($sql);
    }

    echo "Toutes les tables ont été créées avec succès.\n";

} catch (Exception $e) {
    echo " Erreur : " . $e->getMessage() . "\n";
}
